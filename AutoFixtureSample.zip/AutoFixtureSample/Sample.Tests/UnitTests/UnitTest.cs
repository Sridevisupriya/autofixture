﻿using Sample.Tests.Autofixture;
using NUnit.Framework;
using Shouldly;
using System.Threading.Tasks;
using AutoFixture.NUnit3;
using Moq;

namespace Sample.Tests.UnitTests
{
    public class UnitTest
    {
        [Test]
        [UseFakeDependencies]
        public void Create_Class_Instance(AddUserRequest request)
        {
            // auto-generated AddUserRequest
            request.User.Email.ShouldNotBeNullOrWhiteSpace();
            request.User.UserName.ShouldNotBeNullOrWhiteSpace();
        }

        [Test]
        [UseFakeDependencies]
        public async Task Create_Mock_Interface_Implementations(AddUserRequest request, IUserStore userStore)
        {
            // auto-mocked IUserStore
            userStore.ShouldNotBeNull();
            await userStore.AddAsync(request.User);
        }

        [Test]
        [UseFakeDependencies]
        public async Task Dependency_Injection(AddUserRequest request, AddUserUseCase testSubject)
        {
            // AddUserUseCase created and injected with auto-mocked IUserStore
            await testSubject.ProcessAsync(request);
        }

        [Test]
        [UseFakeDependencies]
        public async Task Dependency_Injection_With_Singletons(
            // NOTE: frozen singletons must be declared first in the parameter list
            [Frozen] Mock<IUserStore> mockUserStore,
            AddUserRequest request,
            AddUserUseCase testSubject)
        {
            // AddUserUseCase created and injected with auto-mocked IUserStore singleton
            await testSubject.ProcessAsync(request);
            mockUserStore.Verify(x => x.AddAsync(It.IsAny<User>()), Times.Once);
        }
    }
}
