﻿using AutoFixture;
using AutoFixture.AutoMoq;
using AutoFixture.NUnit3;

namespace Sample.Tests.Autofixture
{
    public class UseRealDependencies : AutoDataAttribute
    {
        public UseRealDependencies() : base(CreateFixture)
        {
        }

        private static IFixture CreateFixture()
        {
            var fixture = new Fixture();

            var addUserRequest = new AddUserRequest
            {
                User = new User
                {
                    Email = "someone@gmail.com",
                    UserName = "someone"
                }
            };

            var userStore = new InMemoryUserStore();
            var addUserUseCase = new AddUserUseCase(userStore);

            fixture.Register(() => addUserRequest);
            fixture.Register(() => addUserUseCase);
            fixture.Customize(new AutoMoqCustomization { ConfigureMembers = true });
            return fixture;
        }
    }
}
