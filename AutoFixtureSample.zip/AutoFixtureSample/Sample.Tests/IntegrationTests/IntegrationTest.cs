﻿using Sample.Tests.Autofixture;
using NUnit.Framework;
using System.Threading.Tasks;

namespace Sample.Tests.IntegrationTests
{
    public class IntegrationTest
    {
        [Test]
        [Category("Integration")]
        [UseRealDependencies]
        public async Task Configure_Custom_Dependencies(AddUserRequest request, AddUserUseCase testSubject)
        {
            // custom dependencies that are registered with our fixture
            await testSubject.ProcessAsync(request);
        }
    }
}
