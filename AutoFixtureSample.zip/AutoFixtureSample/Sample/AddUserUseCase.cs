﻿using System;
using System.Threading.Tasks;

namespace Sample
{
    public class AddUserUseCase
    {
        private readonly IUserStore _userStore;

        public AddUserUseCase(IUserStore userStore)
        {
            if (userStore is null)
            {
                throw new ArgumentNullException(nameof(userStore));
            }

            _userStore = userStore;
        }

        public async Task ProcessAsync(AddUserRequest request)
        {
            bool noEmail = string.IsNullOrWhiteSpace(request?.User?.Email);
            bool noUserName = string.IsNullOrWhiteSpace(request?.User?.UserName);

            if (noEmail)
            {
                throw new ArgumentNullException(nameof(request.User.Email));
            }

            if (noUserName)
            {
                throw new ArgumentNullException(nameof(request.User.UserName));
            }

            await _userStore.AddAsync(request.User);
        }
    }
}
