﻿namespace Sample
{
    public class AddUserRequest
    {
        public User User { get; set; }
    }
}