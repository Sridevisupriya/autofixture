﻿using System.Threading.Tasks;

namespace Sample
{
    public interface IUserStore
    {
        Task AddAsync(User user);
    }
}