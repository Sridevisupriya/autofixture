﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Sample
{
    public class InMemoryUserStore : IUserStore
    {
        private readonly ICollection<User> _users;

        public InMemoryUserStore()
        {
            _users = new LinkedList<User>();
        }

        public async Task AddAsync(User user)
        {
            _users.Add(user);
        }
    }
}
