﻿using System.Collections.Generic;

namespace Sample
{
    public class User
    {
        public string Email { get; set; }
        public string UserName { get; set; }
        public string CurrencyAmount { get; set; }
        public IEnumerable<string> Roles { get; set; }
    }
}